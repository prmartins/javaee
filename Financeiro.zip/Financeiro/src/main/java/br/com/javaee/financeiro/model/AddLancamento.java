package br.com.javaee.financeiro.model;

import java.math.BigDecimal;
import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import br.com.javaee.financeiro.util.JpaUtil;

public class AddLancamento {

	public static void main(String[] args){
		
		EntityManager emf = JpaUtil.getEntityManager();
		EntityTransaction et = emf.getTransaction();
		
		Calendar dataVencimento = Calendar.getInstance();
		dataVencimento.set(2016, 4, 6, 0, 0, 0);
		
		Pessoa cliente = new Pessoa();
		cliente.setNome("Goi�sMinas Santa Helena QUEBRADA LTDA");
		
		Lancamento lancamento = new Lancamento();
		lancamento.setDataVencimento(dataVencimento.getTime());
		lancamento.setDataPagamento(dataVencimento.getTime());
		lancamento.setDescricao("Venda de Produtos de Infraestrutura");
		lancamento.setPessoa(cliente);
		lancamento.setTipo(TipoLancamento.RECEITA);
		lancamento.setValor(new BigDecimal(3000));
		
		et.begin();
		
		emf.persist(cliente);
		emf.persist(lancamento);
		
		et.commit();
		emf.close();
		
		System.exit(0);
		
	}
}
