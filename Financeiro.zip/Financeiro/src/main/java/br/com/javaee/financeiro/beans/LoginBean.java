package br.com.javaee.financeiro.beans;

import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import br.com.javaee.financeiro.controller.Usuario;

@ManagedBean
@RequestScoped
public class LoginBean {
	private String nomeUsuario;
	private String senha;
	private Usuario usuario;
	private String retorno = "";
	
	public LoginBean(){
		usuario = new Usuario();
	}
	
	public String login(){
		FacesContext context = FacesContext.getCurrentInstance();
		
		if("admin".equals(this.nomeUsuario) && "123".equals(this.senha)){
			this.usuario.setNome(this.nomeUsuario);
			this.usuario.setDataLogin(new Date());
			
			retorno = "ConsultaLancamentos?faces-redirect=true";
		}else{
			FacesMessage mensagem = new FacesMessage("Usu�rio/senha inv�lidos!.");
			mensagem.setSeverity(FacesMessage.SEVERITY_ERROR);
			context.addMessage(null, mensagem);
		}
		return retorno;
	}
	
	public String logout(){
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		return "Login?faces-redirect=true";
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

}
