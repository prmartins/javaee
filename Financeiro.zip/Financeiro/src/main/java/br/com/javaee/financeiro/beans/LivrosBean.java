package br.com.javaee.financeiro.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.javaee.financeiro.model.Livro;

@ManagedBean
@ViewScoped
public class LivrosBean {
	private List<Livro> livros = new ArrayList<Livro>();
	private Livro novoLivro;
	
	public LivrosBean(){
		this.livros = new ArrayList<Livro>();
		this.novoLivro = new Livro();
	}
	//public LivrosBean(){
		//this.livros = new ArrayList<Livros>();
		//this.livros.add(new Livro("JAVA EE 7 JSF + PRIMEFACES", "THIAGO FARIA"));
		//this.livros.add(new Livro("MUDANDO A MUDAN�A","PAULO ROCKENBAR"));
		//this.livros.add(new Livro("CONHECENDO WEBSERVICES","ALGAWORKS"));
	//}
	
	public void adicionar(){
		this.livros.add(this.novoLivro);
		novoLivro = new Livro();
	}
	
	public List<Livro> getLivros(){
		return livros;
	}
	
	public void setLivros(List<Livro> livros){
		this.livros = livros;
	}

	public Livro getNovoLivro() {
		return novoLivro;
	}
	
}
