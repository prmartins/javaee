package br.com.javaee.financeiro.beans;

import javax.faces.bean.ManagedBean;;

@ManagedBean
public class ValidadorBean {
	private String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
}
