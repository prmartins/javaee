package br.com.javaee.financeiro.beans;

import java.io.Serializable;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import br.com.javaee.financeiro.model.Lancamento;
import br.com.javaee.financeiro.model.Pessoa;
import br.com.javaee.financeiro.model.TipoLancamento;
import br.com.javaee.financeiro.repository.Lancamentos;
import br.com.javaee.financeiro.repository.Pessoas;
import br.com.javaee.financeiro.service.CadastroLancamentos;
import br.com.javaee.financeiro.service.NegocioException;
import br.com.javaee.financeiro.util.JpaUtil;

@ManagedBean
@ViewScoped
public class CadastroLancamentoBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Lancamento lancamento = null;
	private List<Pessoa> todasPessoas;
	private Lancamentos lancamentos;
	@SuppressWarnings("unused")
	private TipoLancamento[] tiposLancamentos;
	
	public void prepararCadastro(){
		EntityManager manager = JpaUtil.getEntityManager();
		lancamentos = new Lancamentos(manager);
		
		try{
			Pessoas pessoas = new Pessoas(manager);
			this.todasPessoas = pessoas.todas();
			
			if(this.lancamento == null){
				this.lancamento = new Lancamento();
			}
		}catch(Exception e){
		}
	}
	
	public void salvar() throws NegocioException{
		
		EntityManager manager = JpaUtil.getEntityManager();
		EntityTransaction trx = manager.getTransaction();
		FacesContext context = FacesContext.getCurrentInstance();
		
		try{
			trx.begin();
			
			CadastroLancamentos cadastro = new CadastroLancamentos(new Lancamentos(manager));
			cadastro.salvar(this.lancamento);
			
			this.lancamento = new Lancamento();
			context.addMessage(null, new FacesMessage(
					"Lan�amento salvo com sucesso!"));
			
			trx.commit();
		}catch(NegocioException e){
			trx.rollback();
			
			FacesMessage mensagem = new FacesMessage(e.getMessage());
			mensagem.setSeverity(FacesMessage.SEVERITY_ERROR);
			context.addMessage(null, mensagem);
		}finally{
			manager.close();
		}
	}
	
	public List<Pessoa> getTodasPessoas(){
		return this.todasPessoas;
	}
	
	public TipoLancamento[] getTiposLancamentos(){
		return TipoLancamento.values();
	}
	
	public Lancamento getLancamento(){
		return lancamento;
	}
	
	public void setLancamento(Lancamento lancamento){
		this.lancamento = lancamento;
	}
	
	/**
	 * 
	 * @param descricao
	 * @return List<String>
	 * M�todo que realiza a pesquisa chamando m�todo 'descricoesQueContem' do pacote,
	 * br.com.javaee.financeiro.repository
	 */
	public List<String> pesquisarDescricoes(String descricao){
		return this.lancamentos.descricoesQueContem(descricao);
	}
	
}
