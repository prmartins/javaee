package br.com.javaee.financeiro.model;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CriaTabelas {

	public static void main(String[] args) {
		  // TODO Auto-generated method stub
		  
		  EntityManagerFactory emf = Persistence.createEntityManagerFactory("FinanceiroPU");
		  //EntityManager em = emf.createEntityManager();
 
		  //em.close();
		  emf.close();
		  
		 }
}