package br.com.javaee.financeiro.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.component.html.HtmlInputText;

@ManagedBean(name = "nomesBackingBean")
@ApplicationScoped
public class NomesBackingBean {
	private String nome;
	private List<String> nomes = new ArrayList<String>();
	
	private HtmlInputText inputTexto;
	private HtmlCommandButton buttonAdicionar;
	
	public String adicionar(){
		this.nomes.add(nome);
		this.inputTexto.setValue("");
		
		if(this.nomes.size() > 3){
			this.inputTexto.setDisabled(true);
			this.buttonAdicionar.setDisabled(true);
			this.inputTexto.setValue("");
			this.buttonAdicionar.setValue("Limite de nomes excedido.");
			return "Ola?faces-redirect=true";
		}
		return null;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public List<String> getNomes() {
		return nomes;
	}

	public HtmlInputText getInputTexto() {
		return inputTexto;
	}

	public void setInputTexto(HtmlInputText inputTexto) {
		this.inputTexto = inputTexto;
	}

	public HtmlCommandButton getButtonAdicionar() {
		return buttonAdicionar;
	}

	public void setButtonAdicionar(HtmlCommandButton buttonAdicionar) {
		this.buttonAdicionar = buttonAdicionar;
	}
	
	
}
