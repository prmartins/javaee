package br.com.javaee.financeiro.model;

public enum TipoLancamento {
	RECEITA, DESPESA
}